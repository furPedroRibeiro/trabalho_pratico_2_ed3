//Aluno 1: Pedro Luis de Alencar Ribeiro Nº USP: 15590852
//Aluno 2: Bianca Duarte Batista Lacerda Nº USP: 15443221

#include "default_and_eds.h"
#include "geral.h"

#ifndef FUNCIONALIDADE_14_H
#define FUNCIONALIDADE_14_H

void comprimentoCaminhoFofoca(char *nomeArquivoPessoa, char *nomeArquivoIndice, char *nomeArquivoSegueOrdenado, char *nomeUsuarioQueGerouFofoca);
int bfsCiclo(verticeGrafo *vertices, int numVertices, int indiceOrigem);

#endif