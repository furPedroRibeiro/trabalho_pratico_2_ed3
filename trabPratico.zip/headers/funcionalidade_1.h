//Aluno 1: Pedro Luis de Alencar Ribeiro N° USP: 15590852
//Aluno 2: Bianca Duarte Batista Lacerda N° USP: 15443221

//inclui as bibliotecas padrão 
#include "default_and_eds.h"

#ifndef FUNCIONALIDADE_1_H
#define FUNCIONALIDADE_1_H

//funcionalidade 1
void criarIndice(char *nomeArquivoIndice);

#endif